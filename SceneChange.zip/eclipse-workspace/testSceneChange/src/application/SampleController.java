package application;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class SampleController {
	
	public void changeView(ActionEvent ae) throws IOException {
		Stage stage = (Stage) ((Node)ae.getSource()).getScene().getWindow();
		
		BorderPane root = (BorderPane) FXMLLoader.load(getClass().getResource("change.fxml"));
		stage.setScene(new Scene(root , 400 , 400));
		
	}
	
}
